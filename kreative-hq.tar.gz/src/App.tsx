import React from 'react';
import OfficeCanvas from './components/OfficeCanvas';
import './App.css';

function App() {
  return (
    <div className="app">
      <OfficeCanvas />
    </div>
  );
}

export default App;
